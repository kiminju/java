import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.SwingWorker;

public class ViewStudent extends javax.swing.JFrame {
	ArrayList<Student>s_list = new ArrayList<Student>();
    private String name;
    private int age;
    private int phone;//-없이 010빼고 숫자로만 입력
    private String subject;
    StudentManager sm = new StudentManager(s_list,name, age,phone, subject);
	

	/**
	 * Creates new form Students
	 */
	public ViewStudent() {
		
		createMenu();
		setSize(490,500);   
		setVisible(true);
		
		
	}
	void createMenu(){
		JMenuBar mb = new JMenuBar();   
		JMenuItem [] menuItem = new JMenuItem [2]; 
		String[] itemTitle = {"학생관리", "선생님관리"};   
		JMenu Menu1 = new JMenu("학원관리");   
		for(int i=0; i<menuItem.length; i++) {    
			menuItem[i] = new JMenuItem(itemTitle[i]);    
			menuItem[i].addActionListener(new MenuActionListener());    
			Menu1.add(menuItem[i]);   
			}   
		mb.add(Menu1);  
		this.setJMenuBar(mb);
		mb.add(Menu1); 
		JMenu menu2 = new JMenu("프로그램");
		mb.add(menu2);
		
		JMenuItem menu2Item = new JMenuItem("출결프로그램");
		menu2.add(menu2Item);

		menu2Item.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Program1 p1 = new Program1();
			}
		});   
		this.setJMenuBar(mb);
	}
	class MenuActionListener implements ActionListener {   
		 public void actionPerformed(ActionEvent e) {    
			 String cmd = e.getActionCommand();    
			 if(cmd.equals("학생관리"))      
				 initComponents();    
			 else if(cmd.equals("선생님관리"))      
				 initComponents();    
			 else if(cmd.equals("출결프로그램"))      
				 initComponents();    
			 else      
				 initComponents();  }
	 }

	private void initComponents() {

		scrollpane = new javax.swing.JScrollPane();
		tableBook = new javax.swing.JTable();
		loadButton = new javax.swing.JButton();
		deleteButton  = new javax.swing.JButton();
		saveButton = new javax.swing.JButton();
		buttonPanel = new javax.swing.JPanel();
		addButton = new javax.swing.JButton();
		
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("Book Management System");

		tableBook.setModel(new StudentTable(new ArrayList<Student>()));
		scrollpane.setViewportView(tableBook);

		addButton.setText("add ");
		addButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				addButtonActionPerformed(evt);
			}
		});
		
		getContentPane().add(scrollpane, java.awt.BorderLayout.CENTER);
		saveButton.setText("save");
		saveButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				saveButtonActionPerformed(evt);
			}
		});
		loadButton.setText("Load");
		loadButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				loadButtonActionPerformed(evt);
			}
		});
		
		deleteButton.setText("delete");
		deleteButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				deleteButtonActionPerformed(evt);
			}
		});
		
		
		///buttons
		buttonPanel.add(addButton);
		buttonPanel.add(loadButton);
		buttonPanel.add(saveButton);
		buttonPanel.add(deleteButton);
		
		
		
		getContentPane().add(buttonPanel, java.awt.BorderLayout.PAGE_END);
		
		pack();
	}
	
	
	private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt){
		System.out.println("delete button!!!!");
	}
	

	private void addButtonActionPerformed(java.awt.event.ActionEvent evt){
		new Studentadd();
		
		System.out.println("add button!!!!");
	}
	private void loadButtonActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_okButtonActionPerformed
		SwingWorker worker = new SwingWorker() {

			@Override
			protected Object doInBackground() throws Exception {
				// test for books
				List<Student> s_list = new ArrayList<Student>();
				FileInputStream fin = null;
				ObjectInputStream ois = null;

				try {
					fin = new FileInputStream("studentlist.dat");
					ois = new ObjectInputStream(fin);
					ArrayList list = (ArrayList) ois.readObject();
					for (int i = 0; i < list.size(); i++)
						s_list.add((Student) list.get(i));

				} catch (Exception e) {
					System.out.println(e.getMessage());
				} finally {
					try {
						ois.close();
						fin.close();
					} catch (IOException ioe) {
					}
				}
				tableBook.setModel(new StudentTable(s_list));
				return null;
			}
		};
		worker.execute();
	}
	private void saveButtonActionPerformed(java.awt.event.ActionEvent evt){
	      System.out.println("save button!!!!");
	      SwingWorker worker = new SwingWorker() {

	         @Override
	         protected Object doInBackground() throws Exception {
	            // test for books
	        	List<Student> s_list = new ArrayList<Student>();
	            FileOutputStream fout = null;
	            ObjectOutputStream oos = null;

	            try{
	               fout = new FileOutputStream("booklist.dat");
	               oos = new ObjectOutputStream(fout);
	               oos.writeObject(s_list);
	               oos.reset();
	               oos.writeObject(s_list);
	               oos.reset();
	               
	               System.out.println("저장되었습니다.\n");
	               
	            }catch(Exception ex){
	            }finally{
	               try{
	                  oos.close();
	                  fout.close();
	               }catch(IOException ioe){}
	            } // finally
	            tableBook.setModel(new StudentTable(s_list));
	            s_list.clear();
	            return null;
	         }
	      };
	      worker.execute();
	   }

	public static void main(String args[]) {

		/* Create and display the form */
		
		
		String a = "10";
		int b = Integer.parseInt(a);
		System.out.println(b);
		
		new ViewStudent().setVisible(true);

	}
	
	private javax.swing.JButton addButton;
	private javax.swing.JButton loadButton;
	private javax.swing.JButton saveButton;
	private javax.swing.JButton deleteButton;
	private javax.swing.JScrollPane scrollpane;
	private javax.swing.JTable tableBook;
	private javax.swing.JPanel buttonPanel;
	

}
/*
public class ViewStudent extends JFrame {  
	Container contentPane; 
	JLabel label = new JLabel("로그인해주세요"); 


	ViewStudent(){
		setTitle("학원 관리 프로그램");   
		setDefaultCloseOperation(JFrame. EXIT_ON_CLOSE );
		contentPane = getContentPane();
		label.setHorizontalAlignment(SwingConstants. CENTER );   
		contentPane.add(label, BorderLayout. CENTER );
		createMenu();   
		setSize(900,500);   
		setVisible(true);  
	}
	
	void createMenu(){
		JMenuBar mb = new JMenuBar();   
		JMenuItem [] menuItem = new JMenuItem [2]; 
		String[] itemTitle = {"선생님관리", "시간표관리"};   
		JMenu Menu1 = new JMenu("학원관리");   
		for(int i=0; i<menuItem.length; i++) {    
			menuItem[i] = new JMenuItem(itemTitle[i]);    
			menuItem[i].addActionListener(new MenuActionListener());    
			Menu1.add(menuItem[i]);   
			}   
		mb.add(Menu1);  
		this.setJMenuBar(mb);
		mb.add(new JMenu("학생관리"));
		JMenuItem [] menuItem2 = new JMenuItem [2]; 
		String[] itemTitle2 = {"신입생등록", "퇴원생"}; 
		for(int i=0; i<menuItem2.length; i++) {    
			menuItem2[i] = new JMenuItem(itemTitle2[i]);    
			menuItem2[i].addActionListener(new MenuActionListener());    
			Menu1.add(menuItem2[i]);   
			}
		Menu1.addSeparator();
		JMenuItem [] menuItem22 = new JMenuItem [2]; 
		String[] itemTitle22 = {"학생정보/수정", "학생현황조회"}; 
		for(int i=0; i<menuItem22.length; i++) {    
			menuItem22[i] = new JMenuItem(itemTitle22[i]);    
			menuItem22[i].addActionListener(new MenuActionListener());    
			Menu1.add(menuItem22[i]);   
			}
		mb.add(Menu1); 
		mb.add(new JMenu("출결프로그램"));   
		mb.add(new JMenu("자습실프로그램"));     
		this.setJMenuBar(mb);
		} 
	 class MenuActionListener implements ActionListener {   
		 public void actionPerformed(ActionEvent e) {    
			 String cmd = e.getActionCommand();    
			 if(cmd.equals("선생님관리"))      
				 label.setForeground(Color. BLUE );    
			 else if(cmd.equals("시간표관리"))      
				 label.setFont(new Font("Ravie", Font. ITALIC, 30));    
			 else if(cmd.equals("Top"))      
				 label.setVerticalAlignment(SwingConstants. TOP );    
			 else      
				 label.setVerticalAlignment(SwingConstants. BOTTOM );   }
	 }
	 /*
		mb.add(new JMenu("학생관리"));
		fileMenu.add(new JMenuItem("신입생등록"));  
		fileMenu.add(new JMenuItem("퇴원생"));  
		fileMenu.addSeparator();   
		fileMenu.add(new JMenuItem("학생정보/수정"));
		fileMenu.add(new JMenuItem("학생현황조회"));
		mb.add(fileMenu); 
		mb.add(new JMenu("출결프로그램"));   
		mb.add(new JMenu("자습실프로그램"));     
		this.setJMenuBar(mb); 
	}
	
		/*JButton sinput = new JButton("회원관리");      
		JButton alls = new JButton("전체회원");
		JButton inout = new JButton("등하교 관리");
		JButton studyroom = new JButton("자습실관리");
		JLabel teacher = new JLabel("로그인 해주세요");
		JLabel login = new JLabel("기민주 선생님");
		
		void MyPanel() {setBackground(Color. LIGHT_GRAY );
		add(sinput); 
		add(alls);    
		add(inout); 
		add(studyroom);
		add(teacher);
		
		sinput.addActionListener(new ActionListener() {     
			public void actionPerformed(ActionEvent e) {
				while(true){
				String password =JOptionPane.showInputDialog("비밀번호를 입력하세요");
				if(password.equals("1111")){
					System.out.println("환영합니다.");
					remove(teacher);
					add(login);
					setVisible(true);
					break;}
				else{
					JOptionPane.showMessageDialog(null, "비밀번호가 틀렸습니다.","Message",JOptionPane.ERROR_MESSAGE);
				}
				
			}
			}
		});
		alls.addActionListener(new ActionListener() {     
			public void actionPerformed(ActionEvent e) {      
				String id =JOptionPane.showInputDialog("아이디를 입력하세요");
				String password =JOptionPane.showInputDialog("비밀번호를 입력하세요");
				if(id.equals("기민주")&&password.equals("1111"))
					teacher = new JLabel("기민주 교수님");
			}
		});
		
		}
	}
	public static void main(String [] args) {   
		new ViewStudent(); 
	}

	}
	/*/
