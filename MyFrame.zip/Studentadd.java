

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Studentadd extends ViewStudent implements ActionListener {
	private JTextField name;
	private JTextField age;
	private JTextField phone;
	private JTextField subject;
	JButton bt1 = new JButton("등록");
	JButton bt2 = new JButton("취소");
	MyFrame frame = new MyFrame();
	ButtonGroup bg = new ButtonGroup();
	
	public Studentadd(){
	}
	public void init()
	{
		frame.setTitle("신입생");
		frame.setSize(500, 330);
		frame.setLocation(500, 300);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		JLabel mName = new JLabel("학생 이름 :");
		mName.setBounds(27, 16, 90, 30);
		frame.getContentPane().add(mName);
		
		JLabel mAge = new JLabel("학생 나이 :");
		mAge.setBounds(27, 61, 90, 30);
		frame.getContentPane().add(mAge);
		
		JLabel mPhone = new JLabel("학생 전화번호 :");
		mPhone.setBounds(27, 106, 90, 30);
		frame.getContentPane().add(mPhone);
		
		JLabel mAddr = new JLabel("수강 과목 :");
		mAddr.setBounds(27, 152, 90, 30);
		frame.getContentPane().add(mAddr);
		
		name = new JTextField();
		name.setColumns(10);
		name.setBounds(97, 21, 62, 21);
		frame.getContentPane().add(name);
	
		age = new JTextField();
		age.setColumns(10);
		age.setBounds(97, 66, 62, 21);
		frame.getContentPane().add(age);
		
		phone = new JTextField();
		phone.setColumns(10);
		phone.setBounds(129, 111, 144, 21);
		frame.getContentPane().add(phone);
		
		subject = new JTextField();
		subject.setColumns(10);
		subject.setBounds(97, 1, 150, 21);
		frame.getContentPane().add(subject);

		bt1.setBounds(97, 232, 97, 40);
		frame.getContentPane().add(bt1);
		
		bt2.setBounds(280, 232, 97, 40);
		frame.getContentPane().add(bt2);
		
		
		
		frame.setVisible(true);
		
		bt1.addActionListener(this);
		bt2.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == bt1){
			String s_name = name.getText();
			String s_age = age.getText();
			String s_phone = phone.getText();
			String s_subject = subject.getText();
			if(s_name.equals("")){
				JOptionPane.showMessageDialog(this, "학생 이름을 입력해 주세요", "메시지", JOptionPane.INFORMATION_MESSAGE);
			}else if(s_name.equals("")){
				JOptionPane.showMessageDialog(this, "회원 이름을 입력해 주세요", "메시지", JOptionPane.INFORMATION_MESSAGE);
			}else if(s_age.equals("")){
				JOptionPane.showMessageDialog(this, "회원 나이를 입력해 주세요", "메시지", JOptionPane.INFORMATION_MESSAGE);
			}else if(s_phone.equals("")){
				JOptionPane.showMessageDialog(this, "회원 전화번호를 입력해 주세요", "메시지", JOptionPane.INFORMATION_MESSAGE);
			}
			else if(s_subject.equals("")){
				JOptionPane.showMessageDialog(this, "수강과목을 입력해 주세요", "메시지", JOptionPane.INFORMATION_MESSAGE);
			}
			else{
				//for(int i=0; i<s_list.size(); i++){
					//if(s_name.equals(s_list.get(i).getname())){
						//JOptionPane.showMessageDialog(this, "동일한 회원이름이 있습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
					//}
				
				//}
			 if(!integerOrNot(s_age)){
					JOptionPane.showMessageDialog(this, "회원 나이는 문자를 입력할 수 없습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
				}else if(!integerOrNot(s_phone)){
					JOptionPane.showMessageDialog(this, "전화번호는 문자를 입력할 수 없습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
				}else if(!(s_phone.substring(0,2).equals("01") && (s_phone.length() ==10 || s_phone.length() ==11))){
					JOptionPane.showMessageDialog(this, "잘못된 전화번호를 입력하였습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
				}
				else if(!(s_subject.equals("영")||s_subject.equals("영수")||s_subject.equals("수"))){
					JOptionPane.showMessageDialog(this, "과목은 영,영수,수 형태로 입력해주세요.", "메시지", JOptionPane.INFORMATION_MESSAGE);
				}else{
					int check = JOptionPane.showConfirmDialog(this, "입력한 내용이 맞습니까?\n" + 
							"\n학생 이름 : "+s_name + "\n학생 나이 : " + s_age + 
							"\n전화번호 : " + s_phone + "\n수강과목 : " +s_subject,
							"메시지", JOptionPane.INFORMATION_MESSAGE );
					if(check == 0){
						String name = s_name;
						int age = Integer.parseInt(s_age);
						int phone = Integer.parseInt(s_phone);
						String subject = s_subject;
						Student new_student = new Student(name,age,phone,subject);
						s_list.add(new_student);
						}
						JOptionPane.showMessageDialog(this, "회원이 등록되었습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
						int check2 = JOptionPane.showConfirmDialog(this, "계속 입력하시겠습니까?");
						if(check2 == 0){
							name.setText(null);
							age.setText(null);
							phone.setText(null);
							subject.setText(null);
						}else if(check2 == 1){
							frame.setVisible(false);
						}
					}
				}
			}
		else if(e.getSource() == bt2){
			frame.dispose();
		}
	}
	
	public boolean integerOrNot(String strData){ // 입력값이 숫자인지 문자인지 판별 : 
		char[] charData = strData.toCharArray();
		boolean check=true;
		while(check){
			for(int i=0; i<charData.length; i++){		
				if(!Character.isDigit(charData[i])){
						check = !check;
						break;
				}
			}
			break;	
		}return check;
	}



	
	
	
	
}