

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;

public class MyFrame extends JFrame {
	public MyFrame() {
		getContentPane().setLayout(null);
	}
}
